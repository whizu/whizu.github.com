This Whizu zip contains all the jars of the Whizu framework. Additionally all dependencies are provided in the lib folder.

To use in a web project:
1. Copy whizu.jar to WEB-INF/lib in your project
2. Copy lib/*.jar to WEB-INF/lib in your project
